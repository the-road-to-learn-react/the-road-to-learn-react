# Contributor(s)

Many people have made it possible to present *The Road to learn React*, which is currently one of the most downloaded React.js books in circulation. The original author is German software engineer [Robin Wieruch](https://www.robinwieruch.de/), though translations of the book wouldn't be possible without the help of many others. This version of the book got translated by ... [tell your personal story here].

[Note: Translate and complete this paragraph for your own personal pitch. Include your social media account, GitHub account, website or anything else that is personally related to you. It's your opportunity to tell something about your own work as software engineer or translator. Afterward, include it in the Book.txt below the foreword.md that it can be used to compile the finished ebook.]

{pagebreak}